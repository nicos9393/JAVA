/*
!!Blucle infinito
for (let index = 0; index < 10; index=index-1) {
  console.log(index);
} */

/* let numero = 7; */

/* while(condicion){
  console.log("hola");
}

do{
  console.log("hola");
}while(condicion) */

/* for(let i = 0; i < 100; i++){
  console.log(i);
} */

/* while (i < 100) {
  console.log(i);
  i++;
} */

let nacionalidad = "Colombiano";

switch (nacionalidad) {
  case "Argentino":
    console.log("Peso argentino");
    break;

  case "Colombiano":
    alert("Peso colombiano");
    break;

  case "Chileno":
    console.log("Peso chileno");
    break;

  default:
    console.log("Error tu valor ingresado no es correcto");
    break;
}
