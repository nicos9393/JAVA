//comentario de línea

/* 
comentario
de
bloque
*/
/* //no recomendada
var apellido = "Ruiz";

//formas recomendadas
let nombre = "Andres";
let direccion = 'calle 32';

let numero = '3';
const edad = 50;

numero = 5;

console.log(numero);
console.log(apellido);
console.log(edad); */

/* let numero1 = 4;
let numero2 = 5;

//variables con camelCase y constante en mayuscula
let resultadoSuma = numero1 + numero2;
let resultadoResta = numero1 - numero2;
let resultadoMultiplicacion = numero1 * numero2;
const FACTOR = 5;

console.log(resultadoSuma + FACTOR);
console.log(resultadoResta);
console.log(resultadoMultiplicacion); */

/* let nombre = "andres";
let apellido = "velasquez";

console.log(nombre + apellido);
console.log("nombre + 1"); */
/* let numero = 4;


console.log(numero); */

/* let nombre = prompt("Ingresa tu nombre");
console.log(nombre); */
/* let num1 = prompt("ingrese el numero 1");
let num2 = prompt("ingrese el numero 2");

console.log(parseInt(num1) + parseInt(num2)); */
/* let algo = 3;

console.log(typeof(algo)); */
/* let numero = 5;
console.log("acá está el número ", numero); */

/* let num1 = prompt("ingrese el numero 1");
let num2 = prompt("ingrese el numero 2");
let resultado = parseInt(num1) + parseInt(num2);

alert(resultado);
 */

/* let nombre = prompt("Ingrese el nombre");
let apellido = prompt("Ingrese el apellido");
let nombreCompleto = "Su nombre es " + nombre + " " + apellido;

alert(nombreCompleto); */


let algo = prompt("ingresar nombre");
let coso = prompt("ingresar apellido");
let nombreCompleto = "tu nombre es " + algo + " " + coso;

alert (nombreCompleto);

